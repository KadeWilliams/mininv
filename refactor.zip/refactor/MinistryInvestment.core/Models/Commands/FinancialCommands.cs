using System.ComponentModel.DataAnnotations;

namespace MinistryInvestment.Core.Models.Commands
{
    public class SaveFinancialInformationCommand
    {
        public int FinancialInformationId { get; set; }  // 0 = new

        [Required]
        public int OrganizationId { get; set; }

        [Required]
        public DateTime FiscalYearStart { get; set; }

        public decimal Revenue { get; set; }
        public decimal Programs { get; set; }
        public decimal Administration { get; set; }
        public decimal Fundraising { get; set; }
        public decimal Liabilities { get; set; }
        public decimal TotalExpenses { get; set; }
        public decimal Cash { get; set; }

        /// <summary>
        /// DocumentID from ContentServer. 0 if no document attached.
        /// </summary>
        public int DocumentId { get; set; }

        public int FolderId { get; set; }
        public string? Notes { get; set; }
        public string LastChangeUser { get; set; }
    }

    public class DeleteFinancialInformationCommand
    {
        [Required]
        public int FinancialInformationId { get; set; }

        [Required]
        public int OrganizationId { get; set; }

        public string LastChangeUser { get; set; }
    }
}
