using System.ComponentModel.DataAnnotations;

namespace MinistryInvestment.Core.Models.Commands
{
    // -------------------------------------------------------------------------
    // Contact commands
    // -------------------------------------------------------------------------

    public class SaveContactCommand
    {
        public int ContactId { get; set; }           // 0 = new

        [Required]
        public int OrganizationId { get; set; }

        [Required]
        public string ContactName { get; set; }

        public string? Email { get; set; }
        public string? Cell { get; set; }
        public string? Office { get; set; }

        [Required]
        public int ContactTypeId { get; set; }

        public string? ContactNotes { get; set; }
        public string LastChangeUser { get; set; }
        public DateTime LastChangeDttm { get; set; }
    }

    public class DeleteContactCommand
    {
        [Required]
        public int ContactId { get; set; }

        [Required]
        public int OrganizationId { get; set; }

        public string LastChangeUser { get; set; }
    }

    // -------------------------------------------------------------------------
    // Address commands
    // -------------------------------------------------------------------------

    public class SaveAddressCommand
    {
        public int AddressId { get; set; }           // 0 = new

        [Required]
        public int OrganizationId { get; set; }

        public string? AttnLine { get; set; }

        [Required]
        public string? Address1 { get; set; }

        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? ZipCode { get; set; }

        [Required]
        public int CountryId { get; set; }

        public bool Active { get; set; }
        public string LastChangeUser { get; set; }
        public DateTime LastChangeDttm { get; set; }
    }

    public class DeleteAddressCommand
    {
        [Required]
        public int AddressId { get; set; }

        [Required]
        public int OrganizationId { get; set; }

        public string LastChangeUser { get; set; }
    }

    // -------------------------------------------------------------------------
    // Organization commands
    // -------------------------------------------------------------------------

    public class SaveOrganizationCommand
    {
        [Required]
        public Organization Organization { get; set; }

        /// <summary>
        /// The LastChangeDttm read from the form. Used for optimistic concurrency.
        /// Null for new organizations.
        /// </summary>
        public DateTime? PreviousChangeDttm { get; set; }

        public string[] RegionIds { get; set; } = Array.Empty<string>();

        /// <summary>
        /// When true, create/update the ContentServer folder for this org.
        /// </summary>
        public bool EnsureContentServerFolder { get; set; }

        public string LastChangeUser { get; set; }
    }
}
