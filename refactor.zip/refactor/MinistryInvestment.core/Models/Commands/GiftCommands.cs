using System.ComponentModel.DataAnnotations;

namespace MinistryInvestment.Core.Models.Commands
{
    // -------------------------------------------------------------------------
    // Gift commands
    // -------------------------------------------------------------------------

    public class SaveGiftCommand
    {
        public int GiftId { get; set; }             // 0 = new

        [Required]
        public int RequestId { get; set; }

        public int OrganizationId { get; set; }

        public bool Conditional { get; set; }
        public bool Recurring { get; set; }

        [Required, Range(1, double.MaxValue)]
        public double GiftAmount { get; set; }

        public string? PaymentMemo { get; set; }
        public string? GiftNote { get; set; }

        public int FrequencyType { get; set; }
        public int SelectedFrequency { get; set; }
        public DateTime GiftStartDate { get; set; }
        public bool Rebalance { get; set; }

        public string LastChangeUser { get; set; }
        public DateTime LastChangeDttm { get; set; }
    }

    public class DeleteGiftCommand
    {
        [Required]
        public int GiftId { get; set; }

        [Required]
        public int RequestId { get; set; }

        public string LastChangeUser { get; set; }
    }

    // -------------------------------------------------------------------------
    // Gift schedule commands
    // -------------------------------------------------------------------------

    public class SaveGiftScheduleCommand
    {
        public int GiftScheduleId { get; set; }     // 0 = new

        [Required]
        public int GiftId { get; set; }

        [Required]
        public DateTime DisbursementDate { get; set; }

        [Required, Range(1, double.MaxValue)]
        public double Amount { get; set; }

        public double PreviousAmount { get; set; }
        public bool IncludePaymentInfo { get; set; }
        public bool Rebalance { get; set; }

        public string LastChangeUser { get; set; }
    }

    public class DeleteGiftScheduleCommand
    {
        [Required]
        public int GiftScheduleId { get; set; }

        [Required]
        public int GiftId { get; set; }

        public string LastChangeUser { get; set; }
    }

    public class GenerateGiftSchedulesCommand
    {
        [Required]
        public int GiftId { get; set; }

        [Required]
        public int RequestId { get; set; }

        public int FrequencyType { get; set; }

        [Range(1, 24)]
        public int SelectedFrequency { get; set; }

        public DateTime GiftStartDate { get; set; }
        public double GiftAmount { get; set; }

        public string LastChangeUser { get; set; }
    }

    // -------------------------------------------------------------------------
    // Condition commands
    // -------------------------------------------------------------------------

    public class SaveConditionCommand
    {
        public int ConditionId { get; set; }        // 0 = new

        [Required]
        public int GiftId { get; set; }

        [Required]
        public string Description { get; set; }

        public DateTime? Deadline { get; set; }
        public bool Completed { get; set; }

        public string LastChangeUser { get; set; }
    }

    public class DeleteConditionCommand
    {
        [Required]
        public int ConditionId { get; set; }

        [Required]
        public int GiftId { get; set; }

        public string LastChangeUser { get; set; }
    }
}
