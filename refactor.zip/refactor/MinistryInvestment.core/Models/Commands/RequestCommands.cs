using System.ComponentModel.DataAnnotations;

namespace MinistryInvestment.Core.Models.Commands
{
    public class SaveRequestCommand
    {
        public int RequestId { get; set; }           // 0 = new

        [Required]
        public int OrganizationId { get; set; }

        [Required]
        public int Year { get; set; }

        [Required]
        public int Month { get; set; }

        [Required]
        public int VoteTeamId { get; set; }

        [Required]
        public DateTime VoteDate { get; set; }

        [Required, Range(0, double.MaxValue)]
        public double RequestedAmount { get; set; }

        [Required]
        public int ProjectTypeId { get; set; }

        public string? ProjectTypeOther { get; set; }

        [Required]
        public int RequestStatusId { get; set; }

        [Required]
        public string Description { get; set; }

        public string? Response { get; set; }

        /// <summary>
        /// DocumentID of the uploaded One Pager, 0 if none.
        /// </summary>
        public int OnePagerDocumentId { get; set; }

        public int CsFolderId { get; set; }
        public string LastChangeUser { get; set; }
        public DateTime LastChangeDttm { get; set; }
    }

    public class DeleteRequestCommand
    {
        [Required]
        public int RequestId { get; set; }

        [Required]
        public int OrganizationId { get; set; }

        public string LastChangeUser { get; set; }
    }
}
