using System.ComponentModel.DataAnnotations;

namespace MinistryInvestment.Core.Models.Commands
{
    /// <summary>
    /// Generic save/delete pattern for simple lookup tables.
    /// Each lookup type gets its own strongly-typed command so validation
    /// messages are specific and controller signatures are unambiguous.
    /// </summary>

    public class SaveCategoryCommand
    {
        public int CategoryId { get; set; }

        [Required]
        public string CategoryName { get; set; }
    }

    public class SaveRegionCommand
    {
        public int RegionId { get; set; }

        [Required]
        public string RegionName { get; set; }
    }

    public class SavePartnerTypeCommand
    {
        public int PartnerTypeId { get; set; }

        [Required]
        public string PartnerTypeName { get; set; }
    }

    public class SaveContactTypeCommand
    {
        public int ContactTypeId { get; set; }

        [Required]
        public string ContactTypeName { get; set; }
    }

    public class SaveProjectTypeCommand
    {
        public int ProjectTypeId { get; set; }

        [Required]
        public string ProjectTypeName { get; set; }
    }
}
