using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Repositories.Interfaces;
using MinistryInvestment.Core.Services.Interfaces;

namespace MinistryInvestment.Core.Services
{
    public class SearchService : ISearchService
    {
        private readonly ISearchRepository _repo;

        public SearchService(ISearchRepository repo)
        {
            _repo = repo;
        }

        public IEnumerable<T> Search<T>(SearchCriteria searchCriteria) =>
            _repo.GetSearchResults<T>(searchCriteria);
    }
}
