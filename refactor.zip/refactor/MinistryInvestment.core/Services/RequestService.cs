using HobbyLobby.DocumentManagement;
using Microsoft.AspNetCore.Http;
using MinistryInvestment.Core.DocumentManagement;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;
using MinistryInvestment.Core.Repositories.Interfaces;
using MinistryInvestment.Core.Services.Interfaces;

namespace MinistryInvestment.Core.Services
{
    public class RequestService : IRequestService
    {
        private readonly IRequestRepository _repo;
        private readonly IDocumentManagementHelper _documentManagement;

        public RequestService(
            IRequestRepository repo,
            IDocumentManagementHelper documentManagement)
        {
            _repo = repo;
            _documentManagement = documentManagement;
        }

        public Request GetRequest(int requestId) =>
            _repo.GetRequest(requestId);

        public IEnumerable<Request> GetOrganizationRequests(int organizationId) =>
            _repo.GetRequests().Result.Where(r => r.OrganizationID == organizationId);

        public async Task<IEnumerable<Request>> GetRequests() =>
            await _repo.GetRequests();

        public async Task<int> SaveRequest(SaveRequestCommand command)
        {
            command.LastChangeDttm = DateTime.Now;
            return await _repo.SaveRequest(command);
        }

        public void DeleteRequest(DeleteRequestCommand command) =>
            _repo.DeleteRequest(command);

        public async Task<Node> UploadOnePager(int requestId, int csFolderId, IFormFile file)
        {
            if (csFolderId <= 0)
            {
                var request = _repo.GetRequest(requestId);
                var folder = await _documentManagement.CreateOrganizationFolder(request);
                csFolderId = folder.FolderID;
            }
            return await _documentManagement.UploadOnePagerDocument(csFolderId, file);
        }
    }
}
