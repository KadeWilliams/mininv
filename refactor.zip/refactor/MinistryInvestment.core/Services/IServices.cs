using MinistryInvestment.Core.Commands;
using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Core.Services;

// ── Lookup ───────────────────────────────────────────────────────────────────

public interface ILookupService
{
    Task<IEnumerable<Category>> GetCategoriesAsync();
    Task<IEnumerable<ContactType>> GetContactTypesAsync();
    Task<IEnumerable<Country>> GetCountriesAsync();
    Task<IEnumerable<PartnerType>> GetPartnerTypesAsync();
    Task<IEnumerable<ProjectType>> GetProjectTypesAsync();
    Task<IEnumerable<Region>> GetRegionsAsync();
    Task<IEnumerable<RequestStatus>> GetRequestStatusesAsync();
    Task<IEnumerable<VoteTeam>> GetVoteTeamsAsync();

    Task<Category> SaveCategoryAsync(SaveCategoryCommand cmd);
    Task DeleteCategoryAsync(DeleteCategoryCommand cmd);
    Task<Region> SaveRegionAsync(SaveRegionCommand cmd);
    Task DeleteRegionAsync(DeleteRegionCommand cmd);
    Task<PartnerType> SavePartnerTypeAsync(SavePartnerTypeCommand cmd);
    Task DeletePartnerTypeAsync(DeletePartnerTypeCommand cmd);
    Task<ContactType> SaveContactTypeAsync(SaveContactTypeCommand cmd);
    Task DeleteContactTypeAsync(DeleteContactTypeCommand cmd);
    Task<ProjectType> SaveProjectTypeAsync(SaveProjectTypeCommand cmd);
    Task DeleteProjectTypeAsync(DeleteProjectTypeCommand cmd);
}

// ── Organization ─────────────────────────────────────────────────────────────

public interface IOrganizationService
{
    Task<Organization?> GetOrganizationAsync(int organizationId);
    Task<Organization> SaveOrganizationAsync(SaveOrganizationCommand cmd);

    Task<IEnumerable<Contact>> GetContactsAsync(int organizationId);
    Task<Contact> SaveContactAsync(SaveContactCommand cmd);
    Task DeleteContactAsync(DeleteContactCommand cmd);

    Task<IEnumerable<Address>> GetAddressesAsync(int organizationId);
    Task<Address> SaveAddressAsync(SaveAddressCommand cmd);
    Task DeleteAddressAsync(DeleteAddressCommand cmd);
}

// ── Request ───────────────────────────────────────────────────────────────────

public interface IRequestService
{
    Task<IEnumerable<Request>> GetRequestsByOrganizationAsync(int organizationId);
    Task<Request?> GetRequestAsync(int requestId);
    Task<Request> SaveRequestAsync(SaveRequestCommand cmd);
    Task DeleteRequestAsync(DeleteRequestCommand cmd);
    Task<IEnumerable<Request>> GetPendingRequestsAsync();
}

// ── Gift ──────────────────────────────────────────────────────────────────────

public interface IGiftService
{
    Task<IEnumerable<Gift>> GetGiftsByRequestAsync(int requestId);
    Task<Gift?> GetGiftAsync(int giftId);
    Task<Gift> SaveGiftAsync(SaveGiftCommand cmd);
    Task DeleteGiftAsync(DeleteGiftCommand cmd);

    Task<GiftSchedule> SaveGiftScheduleAsync(SaveGiftScheduleCommand cmd);
    Task DeleteGiftScheduleAsync(DeleteGiftScheduleCommand cmd);
    Task GenerateGiftSchedulesAsync(GenerateGiftSchedulesCommand cmd);

    Task<Condition> SaveConditionAsync(SaveConditionCommand cmd);
    Task DeleteConditionAsync(DeleteConditionCommand cmd);
}

// ── Assessment ────────────────────────────────────────────────────────────────

public interface IAssessmentService
{
    Task<IEnumerable<Assessment>> GetAssessmentsByOrganizationAsync(int organizationId);
    Task<Assessment?> GetAssessmentAsync(int assessmentId);
    Task<Assessment> SaveAssessmentAsync(SaveAssessmentCommand cmd);
    Task DeleteAssessmentAsync(DeleteAssessmentCommand cmd);
    Task<IEnumerable<AssessmentCategory>> GetAssessmentFormAsync();
}

// ── Financial ─────────────────────────────────────────────────────────────────

public interface IFinancialService
{
    Task<IEnumerable<FinancialInformation>> GetFinancialsByOrganizationAsync(int organizationId);
    Task<FinancialInformation?> GetFinancialAsync(int financialInformationId);
    Task<FinancialInformation> SaveFinancialAsync(SaveFinancialInformationCommand cmd);
    Task DeleteFinancialAsync(DeleteFinancialInformationCommand cmd);
    Task<IEnumerable<FinancialDocument>> GetFinancialDocumentsAsync(int financialInformationId);
}

// ── Search ────────────────────────────────────────────────────────────────────

public interface ISearchService
{
    Task<IEnumerable<IDictionary<string, object>>> SearchAsync(SearchCriteria criteria);
}
