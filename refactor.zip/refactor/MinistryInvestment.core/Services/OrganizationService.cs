using HobbyLobby.DocumentManagement;
using Microsoft.AspNetCore.Http;
using MinistryInvestment.Core.Configuration;
using MinistryInvestment.Core.DocumentManagement;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;
using MinistryInvestment.Core.Repositories.Interfaces;
using MinistryInvestment.Core.Services.Interfaces;

namespace MinistryInvestment.Core.Services
{
    public class OrganizationService : IOrganizationService
    {
        private readonly IOrganizationRepository _repo;
        private readonly IDocumentManagementHelper _documentManagement;

        public OrganizationService(
            IOrganizationRepository repo,
            IDocumentManagementHelper documentManagement)
        {
            _repo = repo;
            _documentManagement = documentManagement;
        }

        public Organization GetOrganization(int organizationId) =>
            _repo.GetOrganization(organizationId);

        public IEnumerable<Organization> GetOrganizations() =>
            _repo.GetOrganizations();

        public async Task<int> SaveOrganization(SaveOrganizationCommand command)
        {
            command.Organization.LastChangeUser = command.LastChangeUser;
            command.Organization.LastChangeDttm = DateTime.Now;

            if (command.EnsureContentServerFolder && command.Organization.OrganizationID != 0)
            {
                var folder = await _documentManagement.CreateOrganizationFolder(command.Organization);
                command.Organization.CSFolderId = folder.FolderID;
            }

            int organizationId = _repo.SaveOrganization(command.Organization, command.PreviousChangeDttm);

            // Persist region assignments
            if (command.RegionIds != null)
            {
                var regionIdString = string.Join(",", command.RegionIds).Trim(',');
                _repo.SaveOrganizationRegions(organizationId, regionIdString);
            }
            else
            {
                _repo.SaveOrganizationRegions(organizationId, null);
            }

            return organizationId;
        }

        // Contacts
        public IEnumerable<Contact> GetContacts(int organizationId) =>
            _repo.GetContacts(organizationId);

        public int SaveContact(SaveContactCommand command)
        {
            command.LastChangeDttm = DateTime.Now;
            return _repo.SaveContact(command);
        }

        public void DeleteContact(DeleteContactCommand command) =>
            _repo.DeleteContact(command);

        // Addresses
        public IEnumerable<Address> GetAddresses(int organizationId) =>
            _repo.GetAddresses(organizationId);

        public int SaveAddress(SaveAddressCommand command)
        {
            command.LastChangeDttm = DateTime.Now;
            return _repo.SaveAddress(command);
        }

        public void DeleteAddress(DeleteAddressCommand command) =>
            _repo.DeleteAddress(command);

        // Regions
        public IEnumerable<OrganizationRegion> GetOrganizationRegions(int organizationId) =>
            _repo.GetOrganizationRegions(organizationId);

        // Document management
        public async Task<Node> UploadOrganizationLogo(int organizationId, int csFolderId, IFormFile file)
        {
            if (csFolderId <= 0)
            {
                var org = _repo.GetOrganization(organizationId);
                var folder = await _documentManagement.CreateOrganizationFolder(org);
                csFolderId = folder.FolderID;
            }
            return await _documentManagement.UploadOrganizationLogo(csFolderId, file);
        }
    }
}
