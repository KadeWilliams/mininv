using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;
using MinistryInvestment.Core.Repositories.Interfaces;
using MinistryInvestment.Core.Services.Interfaces;

namespace MinistryInvestment.Core.Services
{
    public class GiftService : IGiftService
    {
        private readonly IGiftRepository _repo;

        public GiftService(IGiftRepository repo)
        {
            _repo = repo;
        }

        public Gift GetGift(int giftId) => _repo.GetGift(giftId);
        public IEnumerable<Gift> GetGifts(int requestId) => _repo.GetGifts(requestId);
        public IEnumerable<GiftSchedule> GetGiftSchedules(int giftId) => _repo.GetGiftSchedules(giftId);
        public IEnumerable<Condition> GetConditions(int giftId) => _repo.GetConditions(giftId);

        public int SaveGift(SaveGiftCommand command)
        {
            command.LastChangeDttm = DateTime.Now;
            return _repo.SaveGift(command);
        }

        public void DeleteGift(DeleteGiftCommand command) =>
            _repo.DeleteGift(command);

        public void SaveGiftSchedule(SaveGiftScheduleCommand command) =>
            _repo.SaveGiftSchedule(command);

        public void DeleteGiftSchedule(DeleteGiftScheduleCommand command) =>
            _repo.DeleteGiftSchedule(command);

        public void GenerateSchedules(GenerateGiftSchedulesCommand command) =>
            _repo.GenerateSchedules(command);

        public void SaveCondition(SaveConditionCommand command) =>
            _repo.SaveCondition(command);

        public void DeleteCondition(DeleteConditionCommand command) =>
            _repo.DeleteCondition(command);
    }
}
