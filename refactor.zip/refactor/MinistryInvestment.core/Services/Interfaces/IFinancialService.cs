using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;
using Microsoft.AspNetCore.Http;
using HobbyLobby.DocumentManagement;

namespace MinistryInvestment.Core.Services.Interfaces
{
    public interface IFinancialService
    {
        IEnumerable<FinancialInformation> GetFinancials(int organizationId);
        IEnumerable<FinancialDocument> GetFinancialDocuments(int financialInformationId);

        int SaveFinancialInformation(SaveFinancialInformationCommand command);
        void DeleteFinancialInformation(DeleteFinancialInformationCommand command);

        Task<Node> UploadFinancialDocument(int organizationId, int csFolderId, IFormFile file);
    }
}
