using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;

namespace MinistryInvestment.Core.Services.Interfaces
{
    public interface IGiftService
    {
        Gift GetGift(int giftId);
        IEnumerable<Gift> GetGifts(int requestId);
        IEnumerable<GiftSchedule> GetGiftSchedules(int giftId);
        IEnumerable<Condition> GetConditions(int giftId);

        int SaveGift(SaveGiftCommand command);
        void DeleteGift(DeleteGiftCommand command);

        void SaveGiftSchedule(SaveGiftScheduleCommand command);
        void DeleteGiftSchedule(DeleteGiftScheduleCommand command);
        void GenerateSchedules(GenerateGiftSchedulesCommand command);

        void SaveCondition(SaveConditionCommand command);
        void DeleteCondition(DeleteConditionCommand command);
    }
}
