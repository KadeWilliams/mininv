using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;

namespace MinistryInvestment.Core.Services.Interfaces
{
    /// <summary>
    /// Read/write access to reference/lookup data that is shared across
    /// the rest of the domain. Controllers inject this alongside their
    /// domain-specific service to populate dropdowns.
    /// </summary>
    public interface ILookupService
    {
        IEnumerable<Category> GetCategories();
        IEnumerable<ContactType> GetContactTypes();
        IEnumerable<Country> GetCountries();
        IEnumerable<PartnerType> GetPartnerTypes();
        IEnumerable<ProjectType> GetProjectTypes();
        IEnumerable<Region> GetRegions();
        IEnumerable<RequestStatus> GetRequestStatuses();
        IEnumerable<VoteTeam> GetVoteTeams();

        void SaveCategory(SaveCategoryCommand command);
        void DeleteCategory(int categoryId);

        void SaveRegion(SaveRegionCommand command);
        void DeleteRegion(int regionId);

        void SavePartnerType(SavePartnerTypeCommand command);
        void DeletePartnerType(int partnerTypeId);

        void SaveContactType(SaveContactTypeCommand command);
        void DeleteContactType(int contactTypeId);

        void SaveProjectType(SaveProjectTypeCommand command);
        void DeleteProjectType(int projectTypeId);
    }
}
