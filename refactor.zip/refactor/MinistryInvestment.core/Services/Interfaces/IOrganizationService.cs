using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;
using Microsoft.AspNetCore.Http;
using HobbyLobby.DocumentManagement;

namespace MinistryInvestment.Core.Services.Interfaces
{
    public interface IOrganizationService
    {
        Organization GetOrganization(int organizationId);
        IEnumerable<Organization> GetOrganizations();

        /// <summary>
        /// Returns the saved OrganizationID. A negative return value indicates
        /// a concurrency conflict; the absolute value is the OrganizationID.
        /// </summary>
        Task<int> SaveOrganization(SaveOrganizationCommand command);

        // Contacts
        IEnumerable<Contact> GetContacts(int organizationId);
        int SaveContact(SaveContactCommand command);
        void DeleteContact(DeleteContactCommand command);

        // Addresses
        IEnumerable<Address> GetAddresses(int organizationId);
        int SaveAddress(SaveAddressCommand command);
        void DeleteAddress(DeleteAddressCommand command);

        // Regions
        IEnumerable<OrganizationRegion> GetOrganizationRegions(int organizationId);

        // Document management
        Task<Node> UploadOrganizationLogo(int organizationId, int csFolderId, IFormFile file);
    }
}
