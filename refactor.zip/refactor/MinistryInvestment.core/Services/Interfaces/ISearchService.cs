using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Core.Services.Interfaces
{
    public interface ISearchService
    {
        IEnumerable<T> Search<T>(SearchCriteria searchCriteria);
    }
}
