using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Core.Services.Interfaces
{
    public interface IAssessmentService
    {
        IEnumerable<Assessment> GetAssessments(int organizationId);
        IEnumerable<RequestForAssessment> GetRequestsForAssessment(int organizationId);
        AssessmentDetail GetAssessmentDetail(int assessmentId, int organizationId);
        AssessmentDetail NewAssessmentForm(int organizationId);

        int SaveAssessment(AssessmentScoreSubmission submission, string user);
        void DeleteAssessment(int assessmentId);
    }
}
