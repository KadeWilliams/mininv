using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;
using Microsoft.AspNetCore.Http;
using HobbyLobby.DocumentManagement;

namespace MinistryInvestment.Core.Services.Interfaces
{
    public interface IRequestService
    {
        Request GetRequest(int requestId);
        IEnumerable<Request> GetOrganizationRequests(int organizationId);
        Task<IEnumerable<Request>> GetRequests();

        Task<int> SaveRequest(SaveRequestCommand command);
        void DeleteRequest(DeleteRequestCommand command);

        Task<Node> UploadOnePager(int requestId, int csFolderId, IFormFile file);
    }
}
