using MinistryInvestment.Core.Commands;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Repositories;

namespace MinistryInvestment.Core.Services;

// ── Lookup ───────────────────────────────────────────────────────────────────

public class LookupService(ILookupRepository repo) : ILookupService
{
    public Task<IEnumerable<Category>> GetCategoriesAsync() => repo.GetCategoriesAsync();
    public Task<IEnumerable<ContactType>> GetContactTypesAsync() => repo.GetContactTypesAsync();
    public Task<IEnumerable<Country>> GetCountriesAsync() => repo.GetCountriesAsync();
    public Task<IEnumerable<PartnerType>> GetPartnerTypesAsync() => repo.GetPartnerTypesAsync();
    public Task<IEnumerable<ProjectType>> GetProjectTypesAsync() => repo.GetProjectTypesAsync();
    public Task<IEnumerable<Region>> GetRegionsAsync() => repo.GetRegionsAsync();
    public Task<IEnumerable<RequestStatus>> GetRequestStatusesAsync() => repo.GetRequestStatusesAsync();
    public Task<IEnumerable<VoteTeam>> GetVoteTeamsAsync() => repo.GetVoteTeamsAsync();

    public Task<Category> SaveCategoryAsync(SaveCategoryCommand cmd) => repo.SaveCategoryAsync(cmd);
    public Task DeleteCategoryAsync(DeleteCategoryCommand cmd) => repo.DeleteCategoryAsync(cmd);
    public Task<Region> SaveRegionAsync(SaveRegionCommand cmd) => repo.SaveRegionAsync(cmd);
    public Task DeleteRegionAsync(DeleteRegionCommand cmd) => repo.DeleteRegionAsync(cmd);
    public Task<PartnerType> SavePartnerTypeAsync(SavePartnerTypeCommand cmd) => repo.SavePartnerTypeAsync(cmd);
    public Task DeletePartnerTypeAsync(DeletePartnerTypeCommand cmd) => repo.DeletePartnerTypeAsync(cmd);
    public Task<ContactType> SaveContactTypeAsync(SaveContactTypeCommand cmd) => repo.SaveContactTypeAsync(cmd);
    public Task DeleteContactTypeAsync(DeleteContactTypeCommand cmd) => repo.DeleteContactTypeAsync(cmd);
    public Task<ProjectType> SaveProjectTypeAsync(SaveProjectTypeCommand cmd) => repo.SaveProjectTypeAsync(cmd);
    public Task DeleteProjectTypeAsync(DeleteProjectTypeCommand cmd) => repo.DeleteProjectTypeAsync(cmd);
}

// ── Organization ─────────────────────────────────────────────────────────────

public class OrganizationService(IOrganizationRepository repo) : IOrganizationService
{
    public Task<Organization?> GetOrganizationAsync(int organizationId) =>
        repo.GetOrganizationAsync(organizationId);

    public Task<Organization> SaveOrganizationAsync(SaveOrganizationCommand cmd) =>
        repo.SaveOrganizationAsync(cmd);

    public Task<IEnumerable<Contact>> GetContactsAsync(int organizationId) =>
        repo.GetContactsAsync(organizationId);

    public Task<Contact> SaveContactAsync(SaveContactCommand cmd) =>
        repo.SaveContactAsync(cmd);

    public Task DeleteContactAsync(DeleteContactCommand cmd) =>
        repo.DeleteContactAsync(cmd);

    public Task<IEnumerable<Address>> GetAddressesAsync(int organizationId) =>
        repo.GetAddressesAsync(organizationId);

    public Task<Address> SaveAddressAsync(SaveAddressCommand cmd) =>
        repo.SaveAddressAsync(cmd);

    public Task DeleteAddressAsync(DeleteAddressCommand cmd) =>
        repo.DeleteAddressAsync(cmd);
}

// ── Request ───────────────────────────────────────────────────────────────────

public class RequestService(IRequestRepository repo) : IRequestService
{
    public Task<IEnumerable<Request>> GetRequestsByOrganizationAsync(int organizationId) =>
        repo.GetRequestsByOrganizationAsync(organizationId);

    public Task<Request?> GetRequestAsync(int requestId) =>
        repo.GetRequestAsync(requestId);

    public Task<Request> SaveRequestAsync(SaveRequestCommand cmd) =>
        repo.SaveRequestAsync(cmd);

    public Task DeleteRequestAsync(DeleteRequestCommand cmd) =>
        repo.DeleteRequestAsync(cmd);

    public Task<IEnumerable<Request>> GetPendingRequestsAsync() =>
        repo.GetPendingRequestsAsync();
}

// ── Gift ──────────────────────────────────────────────────────────────────────

public class GiftService(IGiftRepository repo) : IGiftService
{
    public Task<IEnumerable<Gift>> GetGiftsByRequestAsync(int requestId) =>
        repo.GetGiftsByRequestAsync(requestId);

    public Task<Gift?> GetGiftAsync(int giftId) =>
        repo.GetGiftAsync(giftId);

    public Task<Gift> SaveGiftAsync(SaveGiftCommand cmd) =>
        repo.SaveGiftAsync(cmd);

    public Task DeleteGiftAsync(DeleteGiftCommand cmd) =>
        repo.DeleteGiftAsync(cmd);

    public Task<GiftSchedule> SaveGiftScheduleAsync(SaveGiftScheduleCommand cmd) =>
        repo.SaveGiftScheduleAsync(cmd);

    public Task DeleteGiftScheduleAsync(DeleteGiftScheduleCommand cmd) =>
        repo.DeleteGiftScheduleAsync(cmd);

    public Task GenerateGiftSchedulesAsync(GenerateGiftSchedulesCommand cmd) =>
        repo.GenerateGiftSchedulesAsync(cmd);

    public Task<Condition> SaveConditionAsync(SaveConditionCommand cmd) =>
        repo.SaveConditionAsync(cmd);

    public Task DeleteConditionAsync(DeleteConditionCommand cmd) =>
        repo.DeleteConditionAsync(cmd);
}

// ── Assessment ────────────────────────────────────────────────────────────────

public class AssessmentService(IAssessmentRepository repo) : IAssessmentService
{
    public Task<IEnumerable<Assessment>> GetAssessmentsByOrganizationAsync(int organizationId) =>
        repo.GetAssessmentsByOrganizationAsync(organizationId);

    public Task<Assessment?> GetAssessmentAsync(int assessmentId) =>
        repo.GetAssessmentAsync(assessmentId);

    public Task<Assessment> SaveAssessmentAsync(SaveAssessmentCommand cmd) =>
        repo.SaveAssessmentAsync(cmd);

    public Task DeleteAssessmentAsync(DeleteAssessmentCommand cmd) =>
        repo.DeleteAssessmentAsync(cmd);

    public Task<IEnumerable<AssessmentCategory>> GetAssessmentFormAsync() =>
        repo.GetAssessmentFormAsync();
}

// ── Financial ─────────────────────────────────────────────────────────────────

public class FinancialService(IFinancialRepository repo) : IFinancialService
{
    public Task<IEnumerable<FinancialInformation>> GetFinancialsByOrganizationAsync(int organizationId) =>
        repo.GetFinancialsByOrganizationAsync(organizationId);

    public Task<FinancialInformation?> GetFinancialAsync(int financialInformationId) =>
        repo.GetFinancialAsync(financialInformationId);

    public Task<FinancialInformation> SaveFinancialAsync(SaveFinancialInformationCommand cmd) =>
        repo.SaveFinancialAsync(cmd);

    public Task DeleteFinancialAsync(DeleteFinancialInformationCommand cmd) =>
        repo.DeleteFinancialAsync(cmd);

    public Task<IEnumerable<FinancialDocument>> GetFinancialDocumentsAsync(int financialInformationId) =>
        repo.GetFinancialDocumentsAsync(financialInformationId);
}

// ── Search ────────────────────────────────────────────────────────────────────

public class SearchService(ISearchRepository repo) : ISearchService
{
    public Task<IEnumerable<IDictionary<string, object>>> SearchAsync(SearchCriteria criteria) =>
        repo.SearchAsync(criteria);
}
