using HobbyLobby.DocumentManagement;
using Microsoft.AspNetCore.Http;
using MinistryInvestment.Core.Configuration;
using MinistryInvestment.Core.DocumentManagement;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;
using MinistryInvestment.Core.Repositories.Interfaces;
using MinistryInvestment.Core.Services.Interfaces;

namespace MinistryInvestment.Core.Services
{
    public class FinancialService : IFinancialService
    {
        private readonly IFinancialRepository _repo;
        private readonly IDocumentManagementHelper _documentManagement;
        private readonly IMinistryInvestmentConfig _config;

        public FinancialService(
            IFinancialRepository repo,
            IDocumentManagementHelper documentManagement,
            IMinistryInvestmentConfig config)
        {
            _repo = repo;
            _documentManagement = documentManagement;
            _config = config;
        }

        public IEnumerable<FinancialInformation> GetFinancials(int organizationId) =>
            _repo.GetFinancialInformation(organizationId);

        public IEnumerable<FinancialDocument> GetFinancialDocuments(int financialInformationId)
        {
            var documents = _repo.GetFinancialDocuments(financialInformationId);
            foreach (var doc in documents)
            {
                doc.Link = string.Format(_config.ContentServerDocumentURL, doc.DocumentID, doc.FolderID);
            }
            return documents;
        }

        public int SaveFinancialInformation(SaveFinancialInformationCommand command)
        {
            command.LastChangeUser ??= string.Empty;
            int id = _repo.SaveFinancialInformation(command);

            if (command.DocumentId > 0)
            {
                // Build a FinancialInformation for the document save — the repo
                // signature expects the full object for legacy stored proc compatibility.
                var fi = new FinancialInformation
                {
                    FinancialInformationID = id,
                    OrganizationID = command.OrganizationId,
                    DocumentID = command.DocumentId,
                    FolderID = command.FolderId,
                    LastChangeUser = command.LastChangeUser
                };
                _repo.SaveFinancialDocument(fi, command.LastChangeUser).Wait();
            }

            return id;
        }

        public void DeleteFinancialInformation(DeleteFinancialInformationCommand command) =>
            _repo.DeleteFinancialInformation(command);

        public async Task<Node> UploadFinancialDocument(int organizationId, int csFolderId, IFormFile file)
        {
            if (csFolderId <= 0)
            {
                // We need a minimal Organization object to create the folder.
                // The caller is expected to pass a valid csFolderId when possible;
                // this path is the fallback for first-time uploads.
                var org = new Organization { OrganizationID = organizationId };
                var folder = await _documentManagement.CreateOrganizationFolder(org);
                csFolderId = folder.FolderID;
            }
            return await _documentManagement.UploadFinancialDocument(csFolderId, file);
        }
    }
}
