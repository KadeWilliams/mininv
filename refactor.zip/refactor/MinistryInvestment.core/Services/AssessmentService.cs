using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Repositories.Interfaces;
using MinistryInvestment.Core.Services.Interfaces;

namespace MinistryInvestment.Core.Services
{
    public class AssessmentService : IAssessmentService
    {
        private readonly IAssessmentRepository _repo;

        public AssessmentService(IAssessmentRepository repo)
        {
            _repo = repo;
        }

        public IEnumerable<Assessment> GetAssessments(int organizationId) =>
            _repo.GetAssessmentsByOrganization(organizationId);

        public IEnumerable<RequestForAssessment> GetRequestsForAssessment(int organizationId) =>
            _repo.GetRequestsForAssessment(organizationId);

        public AssessmentDetail GetAssessmentDetail(int assessmentId, int organizationId)
        {
            var notes = _repo.GetAssessmentNote(assessmentId);
            var scores = _repo.GetAssessmentScores(assessmentId);
            var requests = _repo.GetRequestsForAssessment(organizationId);
            var selectedRequestId = _repo.GetAssessmentRequestId(assessmentId);

            return BuildAssessmentDetail(assessmentId, scores, requests, organizationId, notes, selectedRequestId);
        }

        public AssessmentDetail NewAssessmentForm(int organizationId)
        {
            var categories = _repo.GetAssessmentCategories();
            var requests = _repo.GetRequestsForAssessment(organizationId);

            var scores = categories.Select(c => new AssessmentScore
            {
                AssessmentCategoryID = c.AssessmentCategoryID,
                Header = c.Header,
                Category = c.Category,
                Description = c.Description,
                Weight = c.Weight,
                Score = 0,
                Notes = null
            });

            return BuildAssessmentDetail(0, scores, requests, organizationId);
        }

        public int SaveAssessment(AssessmentScoreSubmission submission, string user)
        {
            int assessmentId = _repo.SaveAssessment(
                submission.AssessmentID,
                submission.OrganizationID,
                submission.RequestID,
                submission.Notes,
                user);

            _repo.SaveAssessmentScores(assessmentId, submission.Scores, user);
            return assessmentId;
        }

        public void DeleteAssessment(int assessmentId) =>
            _repo.DeleteAssessment(assessmentId);

        // -------------------------------------------------------------------------
        // Private helpers
        // -------------------------------------------------------------------------

        private AssessmentDetail BuildAssessmentDetail(
            int assessmentId,
            IEnumerable<AssessmentScore> scores,
            IEnumerable<RequestForAssessment> requests,
            int organizationId = 0,
            string? notes = null,
            int? selectedRequestId = null)
        {
            var scoreList = scores.ToList();
            var headerGroups = scoreList
                .GroupBy(c => c.Header)
                .Select(g => new AssessmentHeaderGroup
                {
                    Header = g.Key,
                    Questions = g.ToList(),
                    HeaderScore = CalculateHeaderScore(g.ToList())
                })
                .OrderBy(g => g.Header)
                .ToList();

            return new AssessmentDetail
            {
                AssessmentID = assessmentId,
                OrganizationID = organizationId,
                Notes = notes,
                HeaderGroups = headerGroups,
                Requests = requests,
                SelectedRequestID = selectedRequestId
            };
        }

        private static decimal? CalculateHeaderScore(List<AssessmentScore> questions)
        {
            var answered = questions.Where(q => q.Score > 0).ToList();
            if (answered.Count == 0) return null;
            return answered.Sum(q => q.Score);
        }
    }
}
