using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;
using MinistryInvestment.Core.Repositories.Interfaces;
using MinistryInvestment.Core.Services.Interfaces;

namespace MinistryInvestment.Core.Services
{
    public class LookupService : ILookupService
    {
        private readonly ILookupRepository _repo;

        public LookupService(ILookupRepository repo)
        {
            _repo = repo;
        }

        public IEnumerable<Category> GetCategories() => _repo.GetCategories();
        public IEnumerable<ContactType> GetContactTypes() => _repo.GetContactTypes();
        public IEnumerable<Country> GetCountries() => _repo.GetCountries();
        public IEnumerable<PartnerType> GetPartnerTypes() => _repo.GetPartnerTypes();
        public IEnumerable<ProjectType> GetProjectTypes() => _repo.GetProjectTypes();
        public IEnumerable<Region> GetRegions() => _repo.GetRegions();
        public IEnumerable<RequestStatus> GetRequestStatuses() => _repo.GetRequestStatuses();
        public IEnumerable<VoteTeam> GetVoteTeams() => _repo.GetVoteTeams();

        public void SaveCategory(SaveCategoryCommand command) =>
            _repo.SaveCategory(new Category { CategoryId = command.CategoryId, CategoryName = command.CategoryName });

        public void DeleteCategory(int categoryId) =>
            _repo.DeleteCategory(categoryId);

        public void SaveRegion(SaveRegionCommand command) =>
            _repo.SaveRegion(new Region { RegionId = command.RegionId, RegionName = command.RegionName });

        public void DeleteRegion(int regionId) =>
            _repo.DeleteRegion(regionId);

        public void SavePartnerType(SavePartnerTypeCommand command) =>
            _repo.SavePartnerType(new PartnerType { PartnerTypeId = command.PartnerTypeId, PartnerTypeName = command.PartnerTypeName });

        public void DeletePartnerType(int partnerTypeId) =>
            _repo.DeletePartnerType(partnerTypeId);

        public void SaveContactType(SaveContactTypeCommand command) =>
            _repo.SaveContactType(new ContactType { ContactTypeId = command.ContactTypeId, ContactTypeName = command.ContactTypeName });

        public void DeleteContactType(int contactTypeId) =>
            _repo.DeleteContactType(contactTypeId);

        public void SaveProjectType(SaveProjectTypeCommand command) =>
            _repo.SaveProjectType(new ProjectType { ProjectTypeId = command.ProjectTypeId, ProjectTypeName = command.ProjectTypeName });

        public void DeleteProjectType(int projectTypeId) =>
            _repo.DeleteProjectType(projectTypeId);
    }
}
