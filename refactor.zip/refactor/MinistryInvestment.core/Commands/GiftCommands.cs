using System.ComponentModel.DataAnnotations;
using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Core.Commands;

// ── Gift ─────────────────────────────────────────────────────────────────────

public class SaveGiftCommand
{
    public int GiftID { get; set; }

    public int RequestID { get; set; }

    public int OrganizationID { get; set; }

    [Required(ErrorMessage = "Gift amount is required.")]
    [Range(0.01, double.MaxValue, ErrorMessage = "Gift amount must be greater than zero.")]
    public decimal GiftAmount { get; set; }

    public bool Conditional { get; set; }

    public bool Recurring { get; set; }

    public string? PaymentMemo { get; set; }

    public string? GiftNote { get; set; }

    // Condition fields (used when Conditional == true)
    public int? ConditionID { get; set; }
    public string? ConditionDescription { get; set; }
    public DateTime? ConditionDeadline { get; set; }
    public bool ConditionCompleted { get; set; }

    // Generate schedules fields
    public Gift.Frequency FrequencyType { get; set; }
    public int SelectedFrequency { get; set; }
    public DateTime? GiftStartDate { get; set; }

    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteGiftCommand
{
    public int GiftID { get; set; }
    public int RequestID { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

// ── Gift Schedule ─────────────────────────────────────────────────────────────

public class SaveGiftScheduleCommand
{
    public int GiftScheduleID { get; set; }

    public int GiftID { get; set; }

    [Required(ErrorMessage = "Disbursement date is required.")]
    public DateTime DisbursementDate { get; set; }

    [Required(ErrorMessage = "Amount is required.")]
    [Range(0.01, double.MaxValue, ErrorMessage = "Amount must be greater than zero.")]
    public decimal Amount { get; set; }

    public decimal PreviousAmount { get; set; }

    public bool IncludePaymentInfo { get; set; }

    /// <summary>When true, remaining schedules are rebalanced to fill the gift amount.</summary>
    public bool Rebalance { get; set; }

    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteGiftScheduleCommand
{
    public int GiftScheduleID { get; set; }
    public int GiftID { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

public class GenerateGiftSchedulesCommand
{
    public int GiftID { get; set; }
    public Gift.Frequency FrequencyType { get; set; }
    public int SelectedFrequency { get; set; }
    public DateTime GiftStartDate { get; set; }
    public decimal InitialLumpSum { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

// ── Condition ────────────────────────────────────────────────────────────────

public class SaveConditionCommand
{
    public int ConditionID { get; set; }
    public int GiftID { get; set; }
    [Required] public string Description { get; set; } = string.Empty;
    public DateTime? Deadline { get; set; }
    public bool Completed { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteConditionCommand
{
    public int ConditionID { get; set; }
    public int GiftID { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}
