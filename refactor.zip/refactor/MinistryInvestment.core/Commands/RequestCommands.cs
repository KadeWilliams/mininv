using System.ComponentModel.DataAnnotations;

namespace MinistryInvestment.Core.Commands;

public class SaveRequestCommand
{
    public int RequestID { get; set; }

    public int OrganizationID { get; set; }

    [Required(ErrorMessage = "Vote date is required.")]
    public DateTime VoteDate { get; set; }

    [Required(ErrorMessage = "Requested amount is required.")]
    [Range(0.01, double.MaxValue, ErrorMessage = "Requested amount must be greater than zero.")]
    public decimal RequestedAmount { get; set; }

    [Required(ErrorMessage = "Project type is required.")]
    public int ProjectTypeID { get; set; }

    public string? ProjectTypeOther { get; set; }

    [Required(ErrorMessage = "Status is required.")]
    public int RequestStatusID { get; set; }

    public int VoteTeamID { get; set; }

    public string? Description { get; set; }

    public string? Response { get; set; }

    /// <summary>Uploaded one-pager PDF bytes (optional).</summary>
    public byte[]? OnePagerDocument { get; set; }

    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteRequestCommand
{
    public int RequestID { get; set; }
    public int OrganizationID { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}
