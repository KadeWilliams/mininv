using System.ComponentModel.DataAnnotations;

namespace MinistryInvestment.Core.Commands;

// ── Financial Information ─────────────────────────────────────────────────────

public class SaveFinancialInformationCommand
{
    public int FinancialInformationID { get; set; }

    public int OrganizationID { get; set; }

    [Required(ErrorMessage = "Fiscal year is required.")]
    public int FiscalYear { get; set; }

    [Required(ErrorMessage = "Revenue is required.")]
    public decimal Revenue { get; set; }

    public decimal Programs { get; set; }
    public decimal Administration { get; set; }
    public decimal Fundraising { get; set; }
    public decimal Liabilities { get; set; }
    public decimal TotalExpenses { get; set; }
    public decimal Cash { get; set; }

    public string? Notes { get; set; }

    /// <summary>Uploaded financial document (PDF or XLSX) bytes.</summary>
    public byte[]? FinancialDocument { get; set; }

    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteFinancialInformationCommand
{
    public int FinancialInformationID { get; set; }
    public int OrganizationID { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

// ── Assessment ────────────────────────────────────────────────────────────────

public class SaveAssessmentCommand
{
    public int AssessmentID { get; set; }
    public int OrganizationID { get; set; }
    public int RequestID { get; set; }

    /// <summary>Score entries keyed by assessment category description.</summary>
    public Dictionary<string, int> Scores { get; set; } = [];

    public string? Notes { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteAssessmentCommand
{
    public int AssessmentID { get; set; }
    public int OrganizationID { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}
