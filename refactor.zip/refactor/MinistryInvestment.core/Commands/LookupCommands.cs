using System.ComponentModel.DataAnnotations;

namespace MinistryInvestment.Core.Commands;

public class SaveCategoryCommand
{
    public int CategoryId { get; set; }
    [Required(ErrorMessage = "Category name is required.")]
    public string CategoryName { get; set; } = string.Empty;
    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteCategoryCommand
{
    public int CategoryId { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

public class SaveRegionCommand
{
    public int RegionId { get; set; }
    [Required(ErrorMessage = "Region name is required.")]
    public string RegionName { get; set; } = string.Empty;
    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteRegionCommand
{
    public int RegionId { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

public class SavePartnerTypeCommand
{
    public int PartnerTypeId { get; set; }
    [Required(ErrorMessage = "Partner type name is required.")]
    public string PartnerTypeName { get; set; } = string.Empty;
    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeletePartnerTypeCommand
{
    public int PartnerTypeId { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

public class SaveContactTypeCommand
{
    public int ContactTypeId { get; set; }
    [Required(ErrorMessage = "Contact type name is required.")]
    public string ContactTypeName { get; set; } = string.Empty;
    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteContactTypeCommand
{
    public int ContactTypeId { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

public class SaveProjectTypeCommand
{
    public int ProjectTypeId { get; set; }
    [Required(ErrorMessage = "Project type name is required.")]
    public string ProjectTypeName { get; set; } = string.Empty;
    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteProjectTypeCommand
{
    public int ProjectTypeId { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}
