using System.ComponentModel.DataAnnotations;

namespace MinistryInvestment.Core.Commands;

// ── Organization ────────────────────────────────────────────────────────────

public class SaveOrganizationCommand
{
    public int OrganizationID { get; set; }

    [Required(ErrorMessage = "Organization name is required.")]
    public string OrganizationName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Category is required.")]
    public int CategoryID { get; set; }

    public string? CategoryOther { get; set; }

    public int PartnerTypeID { get; set; }

    public string? OrganizationURL { get; set; }

    public string? OrganizationNotes { get; set; }

    /// <summary>Selected region IDs for multi-select.</summary>
    public IEnumerable<int> RegionIDs { get; set; } = [];

    public byte[]? OrganizationLogo { get; set; }

    /// <summary>When true, create/open a Content Server folder.</summary>
    public bool ContentServer { get; set; }

    public int CSFolderId { get; set; }

    public byte[]? VersionStamp { get; set; }

    public DateTime LastChangeDttm { get; set; }

    public string LastChangeUser { get; set; } = string.Empty;
}

// ── Contact ─────────────────────────────────────────────────────────────────

public class SaveContactCommand
{
    public int ContactID { get; set; }

    public int OrganizationID { get; set; }

    [Required(ErrorMessage = "Contact name is required.")]
    public string ContactName { get; set; } = string.Empty;

    public string? Email { get; set; }

    public string? Cell { get; set; }

    public string? Office { get; set; }

    [Required(ErrorMessage = "Contact type is required.")]
    public int ContactTypeID { get; set; }

    public string? ContactNotes { get; set; }

    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteContactCommand
{
    public int ContactID { get; set; }
    public int OrganizationID { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}

// ── Address ──────────────────────────────────────────────────────────────────

public class SaveAddressCommand
{
    public int AddressID { get; set; }

    public int OrganizationID { get; set; }

    public string? AttnLine { get; set; }

    [Required(ErrorMessage = "Address line 1 is required.")]
    public string Address1 { get; set; } = string.Empty;

    public string? Address2 { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? ZipCode { get; set; }

    public int CountryID { get; set; }

    public bool Active { get; set; } = true;

    public string LastChangeUser { get; set; } = string.Empty;
}

public class DeleteAddressCommand
{
    public int AddressID { get; set; }
    public int OrganizationID { get; set; }
    public string LastChangeUser { get; set; } = string.Empty;
}
