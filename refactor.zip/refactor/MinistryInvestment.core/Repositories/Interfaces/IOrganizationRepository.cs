using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;

namespace MinistryInvestment.Core.Repositories.Interfaces
{
    public interface IOrganizationRepository
    {
        Organization GetOrganization(int organizationId);
        IEnumerable<Organization> GetOrganizations();

        /// <summary>
        /// Returns the saved OrganizationID. Passing previousChangeDttm enables
        /// optimistic concurrency; pass null for new organizations.
        /// </summary>
        int SaveOrganization(Organization organization, DateTime? previousChangeDttm);

        // Contacts
        IEnumerable<Contact> GetContacts(int organizationId);
        int SaveContact(SaveContactCommand command);
        void DeleteContact(DeleteContactCommand command);

        // Addresses
        IEnumerable<Address> GetAddresses(int organizationId);
        int SaveAddress(SaveAddressCommand command);
        void DeleteAddress(DeleteAddressCommand command);

        // Regions
        IEnumerable<OrganizationRegion> GetOrganizationRegions(int organizationId);
        void SaveOrganizationRegions(int organizationId, string regionIds);
    }
}
