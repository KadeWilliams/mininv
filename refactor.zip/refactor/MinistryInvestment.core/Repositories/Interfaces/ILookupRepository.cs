using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Core.Repositories.Interfaces
{
    public interface ILookupRepository
    {
        IEnumerable<Category> GetCategories();
        IEnumerable<ContactType> GetContactTypes();
        IEnumerable<Country> GetCountries();
        IEnumerable<PartnerType> GetPartnerTypes();
        IEnumerable<ProjectType> GetProjectTypes();
        IEnumerable<Region> GetRegions();
        IEnumerable<RequestStatus> GetRequestStatuses();
        IEnumerable<VoteTeam> GetVoteTeams();

        void SaveCategory(Category category);
        void DeleteCategory(int categoryId);

        void SaveRegion(Region region);
        void DeleteRegion(int regionId);

        void SavePartnerType(PartnerType partnerType);
        void DeletePartnerType(int partnerTypeId);

        void SaveContactType(ContactType contactType);
        void DeleteContactType(int contactTypeId);

        void SaveProjectType(ProjectType projectType);
        void DeleteProjectType(int projectTypeId);
    }
}
