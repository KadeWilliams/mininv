using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Core.Repositories.Interfaces
{
    public interface IAssessmentRepository
    {
        IEnumerable<Assessment> GetAssessmentsByOrganization(int organizationId);
        IEnumerable<AssessmentScore> GetAssessmentScores(int assessmentId);
        IEnumerable<AssessmentCategory> GetAssessmentCategories();
        IEnumerable<RequestForAssessment> GetRequestsForAssessment(int organizationId);
        string GetAssessmentNote(int assessmentId);
        int? GetAssessmentRequestId(int assessmentId);

        int SaveAssessment(int assessmentId, int organizationId, int requestId, string notes, string user);
        void SaveAssessmentScores(int assessmentId, IEnumerable<ScoreEntry> scores, string user);
        void DeleteAssessment(int assessmentId);
    }
}
