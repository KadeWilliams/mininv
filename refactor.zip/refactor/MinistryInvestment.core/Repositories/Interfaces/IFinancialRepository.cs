using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;

namespace MinistryInvestment.Core.Repositories.Interfaces
{
    public interface IFinancialRepository
    {
        IEnumerable<FinancialInformation> GetFinancialInformation(int organizationId);
        IEnumerable<FinancialDocument> GetFinancialDocuments(int financialInformationId);

        int SaveFinancialInformation(SaveFinancialInformationCommand command);
        Task SaveFinancialDocument(FinancialInformation fi, string user);
        void DeleteFinancialInformation(DeleteFinancialInformationCommand command);
    }
}
