using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;

namespace MinistryInvestment.Core.Repositories.Interfaces
{
    public interface IRequestRepository
    {
        Request GetRequest(int requestId);
        IEnumerable<Request> GetRequests();
        Task<int> SaveRequest(SaveRequestCommand command);
        void DeleteRequest(DeleteRequestCommand command);
    }
}
