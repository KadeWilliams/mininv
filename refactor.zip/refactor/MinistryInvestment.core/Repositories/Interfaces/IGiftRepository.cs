using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Models.Commands;

namespace MinistryInvestment.Core.Repositories.Interfaces
{
    public interface IGiftRepository
    {
        Gift GetGift(int giftId);
        IEnumerable<Gift> GetGifts(int requestId);

        int SaveGift(SaveGiftCommand command);
        void DeleteGift(DeleteGiftCommand command);

        IEnumerable<GiftSchedule> GetGiftSchedules(int giftId);
        void SaveGiftSchedule(SaveGiftScheduleCommand command);
        void DeleteGiftSchedule(DeleteGiftScheduleCommand command);
        void GenerateSchedules(GenerateGiftSchedulesCommand command);

        IEnumerable<Condition> GetConditions(int giftId);
        void SaveCondition(SaveConditionCommand command);
        void DeleteCondition(DeleteConditionCommand command);
    }
}
