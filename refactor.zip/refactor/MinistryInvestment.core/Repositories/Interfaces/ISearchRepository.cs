using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Core.Repositories.Interfaces
{
    public interface ISearchRepository
    {
        IEnumerable<T> GetSearchResults<T>(SearchCriteria searchCriteria);
    }
}
