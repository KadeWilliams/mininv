using Microsoft.Extensions.DependencyInjection;
using MinistryInvestment.Core.Repositories;
using MinistryInvestment.Core.Services;

namespace MinistryInvestment.Mvc;

/// <summary>
/// Wires up all services and repositories.
/// Call <c>builder.Services.AddMinistryInvestmentServices()</c> in Program.cs.
/// </summary>
public static class ServiceRegistrationExtensions
{
    public static IServiceCollection AddMinistryInvestmentServices(this IServiceCollection services)
    {
        // ── Services ──────────────────────────────────────────────────────────
        services.AddScoped<ILookupService,       LookupService>();
        services.AddScoped<IOrganizationService, OrganizationService>();
        services.AddScoped<IRequestService,      RequestService>();
        services.AddScoped<IGiftService,         GiftService>();
        services.AddScoped<IAssessmentService,   AssessmentService>();
        services.AddScoped<IFinancialService,    FinancialService>();
        services.AddScoped<ISearchService,       SearchService>();

        // ── Repositories ──────────────────────────────────────────────────────
        // TODO: Replace each placeholder with your concrete implementation class.
        // The concrete repos should split the existing MinistryInvestmentRepository
        // across the seven domain boundaries defined by each interface.
        //
        // Example when ready:
        //   services.AddScoped<ILookupRepository, LookupRepository>();
        //
        services.AddScoped<ILookupRepository,       PlaceholderLookupRepository>();
        services.AddScoped<IOrganizationRepository, PlaceholderOrganizationRepository>();
        services.AddScoped<IRequestRepository,      PlaceholderRequestRepository>();
        services.AddScoped<IGiftRepository,         PlaceholderGiftRepository>();
        services.AddScoped<IAssessmentRepository,   PlaceholderAssessmentRepository>();
        services.AddScoped<IFinancialRepository,    PlaceholderFinancialRepository>();
        services.AddScoped<ISearchRepository,       PlaceholderSearchRepository>();

        return services;
    }
}
