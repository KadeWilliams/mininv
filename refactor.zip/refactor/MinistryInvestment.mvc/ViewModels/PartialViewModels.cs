using MinistryInvestment.Core.Configuration;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Mvc.Security;

namespace MinistryInvestment.Mvc.ViewModels
{
    public class RequestPartialViewModel : BaseViewModel
    {
        public RequestPartialViewModel(
            IMinistryInvestmentConfig config,
            MenuPermissions menuPermissions,
            LookupData lookups,
            Request request,
            IEnumerable<Gift> gifts)
            : base(config, menuPermissions, lookups)
        {
            Request = request;
            Gifts = gifts;
        }

        public Request Request { get; }
        public IEnumerable<Gift> Gifts { get; }
    }

    public class GiftPartialViewModel : BaseViewModel
    {
        public GiftPartialViewModel(
            IMinistryInvestmentConfig config,
            MenuPermissions menuPermissions,
            Gift gift,
            IEnumerable<GiftSchedule> giftSchedules,
            IEnumerable<Condition> conditions,
            int requestId)
            : base(config, menuPermissions, LookupData.Empty)
        {
            Gift = gift;
            GiftSchedules = giftSchedules;
            Conditions = conditions;
            RequestId = requestId;
        }

        public Gift Gift { get; }
        public IEnumerable<GiftSchedule> GiftSchedules { get; }
        public IEnumerable<Condition> Conditions { get; }
        public int RequestId { get; }
    }
}
