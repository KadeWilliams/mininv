using MinistryInvestment.Core.Configuration;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Mvc.Security;

namespace MinistryInvestment.Mvc.ViewModels
{
    /// <summary>
    /// Maintenance pages (Categories, Regions, PartnerTypes, ContactTypes,
    /// ProjectTypes) all follow the same shape: a list + an error flag.
    /// Each gets a thin typed subclass so Views stay strongly typed.
    /// </summary>
    public abstract class LookupMaintenanceViewModel<T> : BaseViewModel
    {
        protected LookupMaintenanceViewModel(
            IMinistryInvestmentConfig config,
            MenuPermissions menuPermissions,
            IEnumerable<T> items,
            bool error = false)
            : base(config, menuPermissions, LookupData.Empty)
        {
            Items = items;
            Error = error;
        }

        public IEnumerable<T> Items { get; }
        public bool Error { get; }
    }

    public class CategoryViewModel : LookupMaintenanceViewModel<Category>
    {
        public CategoryViewModel(IMinistryInvestmentConfig config, MenuPermissions menuPermissions,
            IEnumerable<Category> categories, bool error = false)
            : base(config, menuPermissions, categories, error) { }
    }

    public class RegionViewModel : LookupMaintenanceViewModel<Region>
    {
        public RegionViewModel(IMinistryInvestmentConfig config, MenuPermissions menuPermissions,
            IEnumerable<Region> regions, bool error = false)
            : base(config, menuPermissions, regions, error) { }
    }

    public class PartnerTypeViewModel : LookupMaintenanceViewModel<PartnerType>
    {
        public PartnerTypeViewModel(IMinistryInvestmentConfig config, MenuPermissions menuPermissions,
            IEnumerable<PartnerType> partnerTypes, bool error = false)
            : base(config, menuPermissions, partnerTypes, error) { }
    }

    public class ContactTypeViewModel : LookupMaintenanceViewModel<ContactType>
    {
        public ContactTypeViewModel(IMinistryInvestmentConfig config, MenuPermissions menuPermissions,
            IEnumerable<ContactType> contactTypes, bool error = false)
            : base(config, menuPermissions, contactTypes, error) { }
    }

    public class ProjectTypeViewModel : LookupMaintenanceViewModel<ProjectType>
    {
        public ProjectTypeViewModel(IMinistryInvestmentConfig config, MenuPermissions menuPermissions,
            IEnumerable<ProjectType> projectTypes, bool error = false)
            : base(config, menuPermissions, projectTypes, error) { }
    }
}
