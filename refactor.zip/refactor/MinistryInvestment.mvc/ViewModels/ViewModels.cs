using MinistryInvestment.Core.Config;
using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Mvc.ViewModels;

// ── Home ─────────────────────────────────────────────────────────────────────

public class HomeViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    IEnumerable<Request> requests)
    : BaseViewModel(config, menuPermissions, lookups)
{
    public IEnumerable<Request> Requests { get; } = requests;
}

// ── Search ────────────────────────────────────────────────────────────────────

public class SearchViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    SearchCriteria searchCriteria)
    : BaseViewModel(config, menuPermissions, lookups)
{
    public SearchCriteria SearchCriteria { get; } = searchCriteria;

    public Microsoft.AspNetCore.Mvc.Rendering.IEnumerable<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem>
        GetSearchFor() => Lookups.GetCategories(); // delegated — keep existing call-site
}

// ── Organization ──────────────────────────────────────────────────────────────

public class OrganizationViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    Organization organization,
    IEnumerable<Request> requests,
    int categoryOtherId,
    int projectTypeOtherId,
    string contentServerFolderUrl,
    int requestId = 0,
    int giftId = 0,
    int addressId = 0,
    int contactId = 0,
    int financialInformationId = 0,
    string message = "")
    : BaseViewModel(config, menuPermissions, lookups)
{
    public Organization Organization { get; } = organization;
    public IEnumerable<Request> Requests { get; } = requests;
    public int CategoryOtherID { get; } = categoryOtherId;
    public int ProjectTypeOtherID { get; } = projectTypeOtherId;
    public string ContentServerFolderURL { get; } = contentServerFolderUrl;
    public int RequestID { get; } = requestId;
    public int GiftID { get; } = giftId;
    public int AddressID { get; } = addressId;
    public int ContactID { get; } = contactId;
    public int FinancialInformationID { get; } = financialInformationId;
    public string Message { get; } = message;
}

// ── Request Partial ───────────────────────────────────────────────────────────

public class RequestPartialViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    Request request,
    IEnumerable<Gift> gifts)
    : BaseViewModel(config, menuPermissions, lookups)
{
    public Request Request { get; } = request;
    public IEnumerable<Gift> Gifts { get; } = gifts;
}

// ── Gift Partial ──────────────────────────────────────────────────────────────

public class GiftPartialViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    Gift gift,
    int requestId)
    : BaseViewModel(config, menuPermissions, lookups)
{
    public Gift Gift { get; } = gift;
    public int RequestID { get; } = requestId;
}

// ── Lookup maintenance (generic base) ─────────────────────────────────────────

public class LookupMaintenanceViewModel<T>(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    IEnumerable<T> items,
    bool hasError = false)
    : BaseViewModel(config, menuPermissions, lookups)
{
    public IEnumerable<T> Items { get; } = items;
    public bool HasError { get; } = hasError;
}

// Typed aliases for each maintenance page

public class CategoryViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    IEnumerable<MinistryInvestment.Core.Models.Category> categories,
    bool hasError = false)
    : LookupMaintenanceViewModel<MinistryInvestment.Core.Models.Category>(config, menuPermissions, lookups, categories, hasError)
{
    public IEnumerable<MinistryInvestment.Core.Models.Category> Categories => Items;
}

public class RegionViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    IEnumerable<Region> regions,
    bool hasError = false)
    : LookupMaintenanceViewModel<Region>(config, menuPermissions, lookups, regions, hasError)
{
    public IEnumerable<Region> Regions => Items;
}

public class PartnerTypeViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    IEnumerable<PartnerType> partnerTypes,
    bool hasError = false)
    : LookupMaintenanceViewModel<PartnerType>(config, menuPermissions, lookups, partnerTypes, hasError)
{
    public IEnumerable<PartnerType> PartnerTypes => Items;
}

public class ContactTypeViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    IEnumerable<ContactType> contactTypes,
    bool hasError = false)
    : LookupMaintenanceViewModel<ContactType>(config, menuPermissions, lookups, contactTypes, hasError)
{
    public IEnumerable<ContactType> ContactTypes => Items;
}

public class ProjectTypeViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups,
    IEnumerable<ProjectType> projectTypes,
    bool hasError = false)
    : LookupMaintenanceViewModel<ProjectType>(config, menuPermissions, lookups, projectTypes, hasError)
{
    public IEnumerable<ProjectType> ProjectTypes => Items;
}
