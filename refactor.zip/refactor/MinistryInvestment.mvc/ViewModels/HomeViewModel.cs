using MinistryInvestment.Core.Configuration;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Mvc.Security;

namespace MinistryInvestment.Mvc.ViewModels
{
    public class HomeViewModel : BaseViewModel
    {
        public HomeViewModel(
            IMinistryInvestmentConfig config,
            MenuPermissions menuPermissions,
            LookupData lookups,
            IEnumerable<Request> requests,
            IEnumerable<Organization> organizations)
            : base(config, menuPermissions, lookups)
        {
            Requests = requests;
            Organizations = organizations;
        }

        public IEnumerable<Request> Requests { get; }
        public IEnumerable<Organization> Organizations { get; }
    }
}
