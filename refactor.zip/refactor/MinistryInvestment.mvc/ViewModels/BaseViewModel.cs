using Microsoft.AspNetCore.Mvc.Rendering;
using MinistryInvestment.Core.Config;
using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Mvc.ViewModels;

/// <summary>
/// Base class for all view models.
/// Requires only the three things every page needs: config, permissions, and lookups.
/// </summary>
public abstract class BaseViewModel(
    IMinistryInvestmentConfig config,
    MenuPermissions menuPermissions,
    LookupData lookups)
{
    public IMinistryInvestmentConfig MinistryInvestmentConfig { get; } = config;
    public MenuPermissions MenuPermissions { get; } = menuPermissions;
    public LookupData Lookups { get; } = lookups;

    // ── Convenience pass-throughs so existing views compile unchanged ─────────

    public IEnumerable<SelectListItem> GetCategories()      => Lookups.GetCategories();
    public IEnumerable<SelectListItem> GetContactTypes()    => Lookups.GetContactTypes();
    public IEnumerable<SelectListItem> GetCountries()       => Lookups.GetCountries();
    public IEnumerable<SelectListItem> GetPartnerTypes()    => Lookups.GetPartnerTypes();
    public IEnumerable<SelectListItem> GetProjectTypes()    => Lookups.GetProjectTypes();
    public IEnumerable<SelectListItem> GetRegions()         => Lookups.GetRegions();
    public IEnumerable<SelectListItem> GetRequestStatuses() => Lookups.GetRequestStatuses();
    public IEnumerable<SelectListItem> GetVoteTeams()       => Lookups.GetVoteTeams();
}
