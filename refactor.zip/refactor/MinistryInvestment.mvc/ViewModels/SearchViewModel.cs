using Microsoft.AspNetCore.Mvc.Rendering;
using MinistryInvestment.Core.Configuration;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Mvc.Security;

namespace MinistryInvestment.Mvc.ViewModels
{
    public class SearchViewModel : BaseViewModel
    {
        public SearchViewModel(
            IMinistryInvestmentConfig config,
            MenuPermissions menuPermissions,
            LookupData lookups,
            SearchCriteria searchCriteria)
            : base(config, menuPermissions, lookups)
        {
            SearchCriteria = searchCriteria;
        }

        public SearchCriteria SearchCriteria { get; }

        /// <summary>
        /// Builds the grouped select list used by TomSelect on the search page.
        /// Values are prefixed with their group name so the search action can
        /// route each token to the right DataTable column (e.g. "Category,3").
        /// </summary>
        public IEnumerable<SelectListItem> GetSearchData()
        {
            var list = new List<SelectListItem>();

            var groupCategory = new SelectListGroup { Name = "Category" };
            var groupStatus = new SelectListGroup { Name = "Status", Disabled = true };
            var groupRegion = new SelectListGroup { Name = "Region" };
            var groupPartnerType = new SelectListGroup { Name = "Partner Type" };
            var groupVoteTeam = new SelectListGroup { Name = "Vote Team", Disabled = true };
            var groupContactType = new SelectListGroup { Name = "Contact Type", Disabled = true };
            var groupProjectType = new SelectListGroup { Name = "Project Type", Disabled = true };
            var groupCountry = new SelectListGroup { Name = "Country" };
            var groupFlags = new SelectListGroup { Name = "Flags" };

            AddGroupedItems(list, GetCategories(), "Category", groupCategory);
            AddGroupedItems(list, GetRequestStatuses(), "Status", groupStatus);
            AddGroupedItems(list, GetRegions(), "Region", groupRegion);
            AddGroupedItems(list, GetPartnerTypes(), "PartnerType", groupPartnerType);
            AddGroupedItems(list, GetVoteTeams(), "Team", groupVoteTeam);
            AddGroupedItems(list, GetContactTypes(), "ContactTypeID", groupContactType);
            AddGroupedItems(list, GetProjectTypes(), "ProjectTypeID", groupProjectType);

            foreach (var flag in Enum.GetNames<SearchFlag>())
            {
                list.Add(new SelectListItem { Value = $"Flag,{flag}", Text = flag, Group = groupFlags });
            }

            // Countries last — TomSelect limits visible items per group,
            // so keeping the large country list at the bottom prevents it
            // from pushing other groups off screen.
            AddGroupedItems(list, GetCountries(), "Country", groupCountry);

            return list;
        }

        public IEnumerable<SelectListItem> GetSearchFor() =>
            new List<SelectListItem>
            {
                new() { Value = "0", Text = "Search Organizations" },
                new() { Value = "1", Text = "Search Requests" },
                new() { Value = "2", Text = "Search Contacts" },
                new() { Value = "3", Text = "Search Gifts" },
            };

        private static void AddGroupedItems(
            List<SelectListItem> list,
            IEnumerable<SelectListItem> items,
            string prefix,
            SelectListGroup group)
        {
            foreach (var item in items)
            {
                list.Add(new SelectListItem
                {
                    Value = $"{prefix},{item.Value}",
                    Text = item.Text,
                    Group = group
                });
            }
        }

        public enum SearchFlag
        {
            Conditional,
            Recurring
        }
    }
}
