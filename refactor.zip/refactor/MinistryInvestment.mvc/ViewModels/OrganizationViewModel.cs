using MinistryInvestment.Core.Configuration;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Mvc.Security;

namespace MinistryInvestment.Mvc.ViewModels
{
    public class OrganizationViewModel : BaseViewModel
    {
        public OrganizationViewModel(
            IMinistryInvestmentConfig config,
            MenuPermissions menuPermissions,
            LookupData lookups,
            Organization organization,
            IEnumerable<Request> requests,
            string contentServerFolderUrl,
            int categoryOtherId,
            int projectTypeOtherId,
            int requestId = 0,
            int giftId = 0,
            int addressId = 0,
            int contactId = 0,
            int financialInformationId = 0,
            bool saveConflict = false,
            string? message = null)
            : base(config, menuPermissions, lookups)
        {
            Organization = organization;
            Requests = requests;
            ContentServerFolderUrl = contentServerFolderUrl;
            CategoryOtherId = categoryOtherId;
            ProjectTypeOtherId = projectTypeOtherId;
            RequestId = requestId;
            GiftId = giftId;
            AddressId = addressId;
            ContactId = contactId;
            FinancialInformationId = financialInformationId;
            SaveConflict = saveConflict;
            Message = message;
        }

        public Organization Organization { get; }
        public IEnumerable<Request> Requests { get; }
        public string ContentServerFolderUrl { get; }
        public int CategoryOtherId { get; }
        public int ProjectTypeOtherId { get; }
        public int RequestId { get; }
        public int GiftId { get; }
        public int AddressId { get; }
        public int ContactId { get; }
        public int FinancialInformationId { get; }
        public bool SaveConflict { get; }
        public string? Message { get; }
    }
}
