using Microsoft.AspNetCore.Mvc.Rendering;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Services;

namespace MinistryInvestment.Mvc.ViewModels;

/// <summary>
/// Immutable bundle of all lookup/reference data needed to render dropdowns.
/// Build once per request via <see cref="CreateAsync"/>, pass into every ViewModel.
/// </summary>
public record LookupData(
    IEnumerable<Category> Categories,
    IEnumerable<ContactType> ContactTypes,
    IEnumerable<Country> Countries,
    IEnumerable<PartnerType> PartnerTypes,
    IEnumerable<ProjectType> ProjectTypes,
    IEnumerable<Region> Regions,
    IEnumerable<RequestStatus> RequestStatuses,
    IEnumerable<VoteTeam> VoteTeams)
{
    /// <summary>
    /// Fetches all lookup data in parallel and returns a populated instance.
    /// Call this once at the top of each controller action that renders a full page.
    /// </summary>
    public static async Task<LookupData> CreateAsync(ILookupService lookup)
    {
        var categories      = lookup.GetCategoriesAsync();
        var contactTypes    = lookup.GetContactTypesAsync();
        var countries       = lookup.GetCountriesAsync();
        var partnerTypes    = lookup.GetPartnerTypesAsync();
        var projectTypes    = lookup.GetProjectTypesAsync();
        var regions         = lookup.GetRegionsAsync();
        var requestStatuses = lookup.GetRequestStatusesAsync();
        var voteTeams       = lookup.GetVoteTeamsAsync();

        await Task.WhenAll(categories, contactTypes, countries, partnerTypes,
                           projectTypes, regions, requestStatuses, voteTeams);

        return new LookupData(
            await categories,
            await contactTypes,
            await countries,
            await partnerTypes,
            await projectTypes,
            await regions,
            await requestStatuses,
            await voteTeams);
    }

    // ── SelectList helpers ───────────────────────────────────────────────────

    public IEnumerable<SelectListItem> GetCategories(int? selectedId = null) =>
        ToSelectList(Categories, x => x.CategoryId.ToString(), x => x.CategoryName, selectedId?.ToString());

    public IEnumerable<SelectListItem> GetContactTypes(int? selectedId = null) =>
        ToSelectList(ContactTypes, x => x.ContactTypeID.ToString(), x => x.ContactTypeName, selectedId?.ToString());

    public IEnumerable<SelectListItem> GetCountries(int? selectedId = null) =>
        ToSelectList(Countries, x => x.CountryID.ToString(), x => x.CountryName, selectedId?.ToString());

    public IEnumerable<SelectListItem> GetPartnerTypes(int? selectedId = null) =>
        ToSelectList(PartnerTypes, x => x.PartnerTypeId.ToString(), x => x.PartnerTypeName, selectedId?.ToString());

    public IEnumerable<SelectListItem> GetProjectTypes(int? selectedId = null) =>
        ToSelectList(ProjectTypes, x => x.ProjectTypeId.ToString(), x => x.ProjectTypeName, selectedId?.ToString());

    public IEnumerable<SelectListItem> GetRegions(int? selectedId = null) =>
        ToSelectList(Regions, x => x.RegionId.ToString(), x => x.RegionName, selectedId?.ToString());

    public IEnumerable<SelectListItem> GetRequestStatuses(int? selectedId = null) =>
        ToSelectList(RequestStatuses, x => x.RequestStatusID.ToString(), x => x.RequestStatusName, selectedId?.ToString());

    public IEnumerable<SelectListItem> GetVoteTeams(int? selectedId = null) =>
        ToSelectList(VoteTeams, x => x.VoteTeamID.ToString(), x => x.VoteTeamName, selectedId?.ToString());

    // ── Private generic helper ───────────────────────────────────────────────

    private static IEnumerable<SelectListItem> ToSelectList<T>(
        IEnumerable<T> source,
        Func<T, string> valueSelector,
        Func<T, string> textSelector,
        string? selectedValue = null)
        => source.Select(item => new SelectListItem
        {
            Value    = valueSelector(item),
            Text     = textSelector(item),
            Selected = selectedValue != null && valueSelector(item) == selectedValue
        });
}
