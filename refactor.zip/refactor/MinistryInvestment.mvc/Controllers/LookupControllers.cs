using HobbyLobby.Avatar.ApplicationSecurity.Authorization;
using HobbyLobby.Avatar.AspNetCore.Authorization;
using HobbyLobby.Logging;
using Microsoft.AspNetCore.Mvc;
using MinistryInvestment.Core.Configuration;
using MinistryInvestment.Core.Models.Commands;
using MinistryInvestment.Core.Services.Interfaces;
using MinistryInvestment.Mvc.Security;
using MinistryInvestment.Mvc.ViewModels;

namespace MinistryInvestment.Mvc.Controllers
{
    /// <summary>
    /// Each lookup maintenance controller follows the exact same pattern:
    ///   GET  Index            — list all items
    ///   POST Save[Type]       — upsert (id == 0 means new)
    ///   POST Delete[Type]     — delete by id
    ///
    /// The old "-1" sentinel value for deletes is replaced with explicit
    /// Delete actions so intent is unambiguous and ModelState works cleanly.
    /// </summary>

    public class CategoriesController : BaseController
    {
        private readonly ILookupService _lookupService;

        public CategoriesController(
            IMinistryInvestmentConfig config, ILog log,
            IAccessTokenClaimAuthorizationService authorizationService,
            ILookupService lookupService)
            : base(config, log, authorizationService)
        {
            _lookupService = lookupService;
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        public async Task<ActionResult> Index(bool error = false)
        {
            var vm = new CategoryViewModel(Config, await GetMenuPermissions(),
                _lookupService.GetCategories(), error);
            return View(vm);
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult SaveCategory(SaveCategoryCommand command)
        {
            if (!ModelState.IsValid) return RedirectToAction("Index", new { error = true });
            try { _lookupService.SaveCategory(command); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult DeleteCategory(int id)
        {
            try { _lookupService.DeleteCategory(id); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }
    }

    public class RegionsController : BaseController
    {
        private readonly ILookupService _lookupService;

        public RegionsController(
            IMinistryInvestmentConfig config, ILog log,
            IAccessTokenClaimAuthorizationService authorizationService,
            ILookupService lookupService)
            : base(config, log, authorizationService)
        {
            _lookupService = lookupService;
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        public async Task<ActionResult> Index(bool error = false)
        {
            var vm = new RegionViewModel(Config, await GetMenuPermissions(),
                _lookupService.GetRegions(), error);
            return View(vm);
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult SaveRegion(SaveRegionCommand command)
        {
            if (!ModelState.IsValid) return RedirectToAction("Index", new { error = true });
            try { _lookupService.SaveRegion(command); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult DeleteRegion(int id)
        {
            try { _lookupService.DeleteRegion(id); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }
    }

    public class PartnerTypesController : BaseController
    {
        private readonly ILookupService _lookupService;

        public PartnerTypesController(
            IMinistryInvestmentConfig config, ILog log,
            IAccessTokenClaimAuthorizationService authorizationService,
            ILookupService lookupService)
            : base(config, log, authorizationService)
        {
            _lookupService = lookupService;
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        public async Task<ActionResult> Index(bool error = false)
        {
            var vm = new PartnerTypeViewModel(Config, await GetMenuPermissions(),
                _lookupService.GetPartnerTypes(), error);
            return View(vm);
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult SavePartnerType(SavePartnerTypeCommand command)
        {
            if (!ModelState.IsValid) return RedirectToAction("Index", new { error = true });
            try { _lookupService.SavePartnerType(command); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult DeletePartnerType(int id)
        {
            try { _lookupService.DeletePartnerType(id); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }
    }

    public class ContactTypesController : BaseController
    {
        private readonly ILookupService _lookupService;

        public ContactTypesController(
            IMinistryInvestmentConfig config, ILog log,
            IAccessTokenClaimAuthorizationService authorizationService,
            ILookupService lookupService)
            : base(config, log, authorizationService)
        {
            _lookupService = lookupService;
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        public async Task<ActionResult> Index(bool error = false)
        {
            var vm = new ContactTypeViewModel(Config, await GetMenuPermissions(),
                _lookupService.GetContactTypes(), error);
            return View(vm);
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult SaveContactType(SaveContactTypeCommand command)
        {
            if (!ModelState.IsValid) return RedirectToAction("Index", new { error = true });
            try { _lookupService.SaveContactType(command); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult DeleteContactType(int id)
        {
            try { _lookupService.DeleteContactType(id); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }
    }

    public class ProjectTypesController : BaseController
    {
        private readonly ILookupService _lookupService;

        public ProjectTypesController(
            IMinistryInvestmentConfig config, ILog log,
            IAccessTokenClaimAuthorizationService authorizationService,
            ILookupService lookupService)
            : base(config, log, authorizationService)
        {
            _lookupService = lookupService;
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        public async Task<ActionResult> Index(bool error = false)
        {
            var vm = new ProjectTypeViewModel(Config, await GetMenuPermissions(),
                _lookupService.GetProjectTypes(), error);
            return View(vm);
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult SaveProjectType(SaveProjectTypeCommand command)
        {
            if (!ModelState.IsValid) return RedirectToAction("Index", new { error = true });
            try { _lookupService.SaveProjectType(command); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }

        [ClaimAuthorize(CheckAuthorization.ADMIN)]
        [HttpPost]
        public IActionResult DeleteProjectType(int id)
        {
            try { _lookupService.DeleteProjectType(id); }
            catch (Exception ex) { Log.Error($"{ex}"); return RedirectToAction("Index", new { error = true }); }
            return RedirectToAction("Index");
        }
    }
}
