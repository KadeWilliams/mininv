using log4net;
using Microsoft.AspNetCore.Mvc;
using MinistryInvestment.Core.Auth;
using MinistryInvestment.Core.Config;
using MinistryInvestment.Core.Models;

namespace MinistryInvestment.Mvc.Controllers;

/// <summary>
/// Provides shared infrastructure: config, logging, permissions.
/// Domain services are injected directly in each sub-controller.
/// </summary>
public abstract class BaseController(
    IMinistryInvestmentConfig config,
    ILog log,
    IAccessTokenClaimAuthorizationService authService) : Controller
{
    protected readonly IMinistryInvestmentConfig Config = config;
    protected readonly ILog Log = log;
    protected readonly IAccessTokenClaimAuthorizationService AuthService = authService;

    protected MenuPermissions GetMenuPermissions() => new()
    {
        HasReadPermissions  = AuthService.HasReadPermissions(User.Claims),
        HasEditPermissions  = AuthService.HasEditPermissions(User.Claims),
        HasAdminPermissions = AuthService.HasAdminPermissions(User.Claims),
    };

    protected IActionResult ErrorRedirect(Exception ex, string context)
    {
        Log.Error($"[{context}] {ex.Message}", ex);
        return RedirectToAction("Index", "Error");
    }
}
