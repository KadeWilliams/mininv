using log4net;
using Microsoft.AspNetCore.Mvc;
using MinistryInvestment.Core.Auth;
using MinistryInvestment.Core.Commands;
using MinistryInvestment.Core.Config;
using MinistryInvestment.Core.Models;
using MinistryInvestment.Core.Services;
using MinistryInvestment.Mvc.ViewModels;

namespace MinistryInvestment.Mvc.Controllers;

// ── Home ─────────────────────────────────────────────────────────────────────

public class HomeController(
    IMinistryInvestmentConfig config,
    ILog log,
    IAccessTokenClaimAuthorizationService authService,
    IRequestService requestService,
    ILookupService lookupService)
    : BaseController(config, log, authService)
{
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        try
        {
            var lookups  = await LookupData.CreateAsync(lookupService);
            var pending  = await requestService.GetPendingRequestsAsync();
            var vm       = new HomeViewModel(Config, GetMenuPermissions(), lookups, pending);
            return View(vm);
        }
        catch (Exception ex) { return ErrorRedirect(ex, nameof(Index)); }
    }
}

// ── Search ────────────────────────────────────────────────────────────────────

public class SearchController(
    IMinistryInvestmentConfig config,
    ILog log,
    IAccessTokenClaimAuthorizationService authService,
    ISearchService searchService,
    ILookupService lookupService)
    : BaseController(config, log, authService)
{
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        try
        {
            var lookups = await LookupData.CreateAsync(lookupService);
            var vm      = new SearchViewModel(Config, GetMenuPermissions(), lookups, new SearchCriteria());
            return View(vm);
        }
        catch (Exception ex) { return ErrorRedirect(ex, nameof(Index)); }
    }

    [HttpPost]
    public async Task<IActionResult> Search(SearchCriteria criteria)
    {
        try
        {
            var results = await searchService.SearchAsync(criteria);
            return Json(results);
        }
        catch (Exception ex)
        {
            Log.Error(ex.Message, ex);
            return StatusCode(500);
        }
    }
}

// ── Lookup Maintenance ────────────────────────────────────────────────────────

public class CategoriesController(
    IMinistryInvestmentConfig config,
    ILog log,
    IAccessTokenClaimAuthorizationService authService,
    ILookupService lookupService)
    : BaseController(config, log, authService)
{
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var lookups     = await LookupData.CreateAsync(lookupService);
        var categories  = await lookupService.GetCategoriesAsync();
        return View(new CategoryViewModel(Config, GetMenuPermissions(), lookups, categories));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(SaveCategoryCommand cmd)
    {
        if (!ModelState.IsValid) return RedirectToAction(nameof(Index));
        cmd.LastChangeUser = User.Identity?.Name ?? "system";
        await lookupService.SaveCategoryAsync(cmd);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(DeleteCategoryCommand cmd)
    {
        try
        {
            cmd.LastChangeUser = User.Identity?.Name ?? "system";
            await lookupService.DeleteCategoryAsync(cmd);
        }
        catch (Exception ex) { Log.Error(ex.Message, ex); return RedirectToAction(nameof(Index), new { error = true }); }
        return RedirectToAction(nameof(Index));
    }
}

public class RegionsController(
    IMinistryInvestmentConfig config,
    ILog log,
    IAccessTokenClaimAuthorizationService authService,
    ILookupService lookupService)
    : BaseController(config, log, authService)
{
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var lookups = await LookupData.CreateAsync(lookupService);
        var regions = await lookupService.GetRegionsAsync();
        return View(new RegionViewModel(Config, GetMenuPermissions(), lookups, regions));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(SaveRegionCommand cmd)
    {
        if (!ModelState.IsValid) return RedirectToAction(nameof(Index));
        cmd.LastChangeUser = User.Identity?.Name ?? "system";
        await lookupService.SaveRegionAsync(cmd);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(DeleteRegionCommand cmd)
    {
        try
        {
            cmd.LastChangeUser = User.Identity?.Name ?? "system";
            await lookupService.DeleteRegionAsync(cmd);
        }
        catch (Exception ex) { Log.Error(ex.Message, ex); return RedirectToAction(nameof(Index), new { error = true }); }
        return RedirectToAction(nameof(Index));
    }
}

public class PartnerTypesController(
    IMinistryInvestmentConfig config,
    ILog log,
    IAccessTokenClaimAuthorizationService authService,
    ILookupService lookupService)
    : BaseController(config, log, authService)
{
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var lookups      = await LookupData.CreateAsync(lookupService);
        var partnerTypes = await lookupService.GetPartnerTypesAsync();
        return View(new PartnerTypeViewModel(Config, GetMenuPermissions(), lookups, partnerTypes));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(SavePartnerTypeCommand cmd)
    {
        if (!ModelState.IsValid) return RedirectToAction(nameof(Index));
        cmd.LastChangeUser = User.Identity?.Name ?? "system";
        await lookupService.SavePartnerTypeAsync(cmd);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(DeletePartnerTypeCommand cmd)
    {
        try { await lookupService.DeletePartnerTypeAsync(cmd); }
        catch (Exception ex) { Log.Error(ex.Message, ex); }
        return RedirectToAction(nameof(Index));
    }
}

public class ContactTypesController(
    IMinistryInvestmentConfig config,
    ILog log,
    IAccessTokenClaimAuthorizationService authService,
    ILookupService lookupService)
    : BaseController(config, log, authService)
{
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var lookups      = await LookupData.CreateAsync(lookupService);
        var contactTypes = await lookupService.GetContactTypesAsync();
        return View(new ContactTypeViewModel(Config, GetMenuPermissions(), lookups, contactTypes));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(SaveContactTypeCommand cmd)
    {
        if (!ModelState.IsValid) return RedirectToAction(nameof(Index));
        cmd.LastChangeUser = User.Identity?.Name ?? "system";
        await lookupService.SaveContactTypeAsync(cmd);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(DeleteContactTypeCommand cmd)
    {
        try { await lookupService.DeleteContactTypeAsync(cmd); }
        catch (Exception ex) { Log.Error(ex.Message, ex); }
        return RedirectToAction(nameof(Index));
    }
}

public class ProjectTypesController(
    IMinistryInvestmentConfig config,
    ILog log,
    IAccessTokenClaimAuthorizationService authService,
    ILookupService lookupService)
    : BaseController(config, log, authService)
{
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var lookups      = await LookupData.CreateAsync(lookupService);
        var projectTypes = await lookupService.GetProjectTypesAsync();
        return View(new ProjectTypeViewModel(Config, GetMenuPermissions(), lookups, projectTypes));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(SaveProjectTypeCommand cmd)
    {
        if (!ModelState.IsValid) return RedirectToAction(nameof(Index));
        cmd.LastChangeUser = User.Identity?.Name ?? "system";
        await lookupService.SaveProjectTypeAsync(cmd);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(DeleteProjectTypeCommand cmd)
    {
        try { await lookupService.DeleteProjectTypeAsync(cmd); }
        catch (Exception ex) { Log.Error(ex.Message, ex); }
        return RedirectToAction(nameof(Index));
    }
}
