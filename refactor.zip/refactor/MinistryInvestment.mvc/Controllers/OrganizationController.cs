using log4net;
using Microsoft.AspNetCore.Mvc;
using MinistryInvestment.Core.Auth;
using MinistryInvestment.Core.Commands;
using MinistryInvestment.Core.Config;
using MinistryInvestment.Core.Services;
using MinistryInvestment.Mvc.ViewModels;

namespace MinistryInvestment.Mvc.Controllers;

public class OrganizationController(
    IMinistryInvestmentConfig config,
    ILog log,
    IAccessTokenClaimAuthorizationService authService,
    IOrganizationService organizationService,
    IRequestService requestService,
    IGiftService giftService,
    IAssessmentService assessmentService,
    IFinancialService financialService,
    ILookupService lookupService)
    : BaseController(config, log, authService)
{
    // ── Index ─────────────────────────────────────────────────────────────────

    [HttpGet]
    public async Task<IActionResult> Index(int organizationId = 0, int requestId = 0, int giftId = 0,
        int addressId = 0, int contactId = 0, int financialInformationId = 0)
    {
        try
        {
            var lookups     = await LookupData.CreateAsync(lookupService);
            var permissions = GetMenuPermissions();
            var org         = organizationId > 0
                                  ? await organizationService.GetOrganizationAsync(organizationId)
                                  : new MinistryInvestment.Core.Models.Organization();
            var requests    = organizationId > 0
                                  ? await requestService.GetRequestsByOrganizationAsync(organizationId)
                                  : Enumerable.Empty<MinistryInvestment.Core.Models.Request>();

            var vm = new OrganizationViewModel(
                config, permissions, lookups, org!, requests,
                GetCategoryOtherId(lookups), GetProjectTypeOtherId(lookups),
                config.ContentServerFolderURL,
                requestId, giftId, addressId, contactId, financialInformationId);

            return View(vm);
        }
        catch (Exception ex) { return ErrorRedirect(ex, nameof(Index)); }
    }

    // ── Save Organization ─────────────────────────────────────────────────────

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveOrganization(SaveOrganizationCommand cmd)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            cmd.LastChangeUser = CurrentUser;
            var saved = await organizationService.SaveOrganizationAsync(cmd);
            return RedirectToAction(nameof(Index), new { organizationId = saved.OrganizationID });
        }
        catch (Exception ex) { return ErrorRedirect(ex, nameof(SaveOrganization)); }
    }

    // ── Contacts ──────────────────────────────────────────────────────────────

    [HttpGet]
    public async Task<IActionResult> GetContacts(int organizationId) =>
        Json(await organizationService.GetContactsAsync(organizationId));

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveContact(SaveContactCommand cmd)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        cmd.LastChangeUser = CurrentUser;
        return Json(await organizationService.SaveContactAsync(cmd));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteContact(DeleteContactCommand cmd)
    {
        cmd.LastChangeUser = CurrentUser;
        await organizationService.DeleteContactAsync(cmd);
        return Json(new { success = true });
    }

    // ── Addresses ─────────────────────────────────────────────────────────────

    [HttpGet]
    public async Task<IActionResult> GetAddresses(int organizationId) =>
        Json(await organizationService.GetAddressesAsync(organizationId));

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveAddress(SaveAddressCommand cmd)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        cmd.LastChangeUser = CurrentUser;
        return Json(await organizationService.SaveAddressAsync(cmd));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteAddress(DeleteAddressCommand cmd)
    {
        cmd.LastChangeUser = CurrentUser;
        await organizationService.DeleteAddressAsync(cmd);
        return Json(new { success = true });
    }

    // ── Request Partial ───────────────────────────────────────────────────────

    [HttpGet]
    public async Task<IActionResult> RequestFormPartial(int requestId, int organizationId)
    {
        try
        {
            var lookups     = await LookupData.CreateAsync(lookupService);
            var permissions = GetMenuPermissions();
            var request     = requestId > 0
                                  ? await requestService.GetRequestAsync(requestId)
                                  : new MinistryInvestment.Core.Models.Request { OrganizationID = organizationId };
            var gifts       = requestId > 0
                                  ? await giftService.GetGiftsByRequestAsync(requestId)
                                  : Enumerable.Empty<MinistryInvestment.Core.Models.Gift>();

            return PartialView("_RequestPartial",
                new RequestPartialViewModel(config, permissions, lookups, request!, gifts));
        }
        catch (Exception ex) { return ErrorRedirect(ex, nameof(RequestFormPartial)); }
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveRequest(SaveRequestCommand cmd)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        cmd.LastChangeUser = CurrentUser;
        var saved = await requestService.SaveRequestAsync(cmd);
        return Json(new { requestId = saved.RequestID });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteRequest(DeleteRequestCommand cmd)
    {
        cmd.LastChangeUser = CurrentUser;
        await requestService.DeleteRequestAsync(cmd);
        return Json(new { success = true });
    }

    // ── Gift Partial ──────────────────────────────────────────────────────────

    [HttpGet]
    public async Task<IActionResult> LoadGiftPartial(int giftId, int requestId, int organizationId)
    {
        try
        {
            var lookups     = await LookupData.CreateAsync(lookupService);
            var permissions = GetMenuPermissions();
            var gift        = giftId > 0
                                  ? await giftService.GetGiftAsync(giftId)
                                  : new MinistryInvestment.Core.Models.Gift { RequestID = requestId };

            return PartialView("_GiftPartial",
                new GiftPartialViewModel(config, permissions, lookups, gift!, requestId));
        }
        catch (Exception ex) { return ErrorRedirect(ex, nameof(LoadGiftPartial)); }
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveGift(SaveGiftCommand cmd)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        cmd.LastChangeUser = CurrentUser;
        var saved = await giftService.SaveGiftAsync(cmd);
        return Json(new { giftId = saved.GiftID });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteGift(DeleteGiftCommand cmd)
    {
        cmd.LastChangeUser = CurrentUser;
        await giftService.DeleteGiftAsync(cmd);
        return Json(new { success = true });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveGiftSchedule(SaveGiftScheduleCommand cmd)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        cmd.LastChangeUser = CurrentUser;
        return Json(await giftService.SaveGiftScheduleAsync(cmd));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteGiftSchedule(DeleteGiftScheduleCommand cmd)
    {
        cmd.LastChangeUser = CurrentUser;
        await giftService.DeleteGiftScheduleAsync(cmd);
        return Json(new { success = true });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> GenerateGiftSchedules(GenerateGiftSchedulesCommand cmd)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        cmd.LastChangeUser = CurrentUser;
        await giftService.GenerateGiftSchedulesAsync(cmd);
        return Json(new { success = true });
    }

    // ── Assessments ───────────────────────────────────────────────────────────

    [HttpGet]
    public async Task<IActionResult> GetAssessments(int organizationId) =>
        Json(await assessmentService.GetAssessmentsByOrganizationAsync(organizationId));

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveAssessment(SaveAssessmentCommand cmd)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        cmd.LastChangeUser = CurrentUser;
        return Json(await assessmentService.SaveAssessmentAsync(cmd));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteAssessment(DeleteAssessmentCommand cmd)
    {
        cmd.LastChangeUser = CurrentUser;
        await assessmentService.DeleteAssessmentAsync(cmd);
        return Json(new { success = true });
    }

    // ── Financials ────────────────────────────────────────────────────────────

    [HttpGet]
    public async Task<IActionResult> GetFinancials(int organizationId) =>
        Json(await financialService.GetFinancialsByOrganizationAsync(organizationId));

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveFinancial(SaveFinancialInformationCommand cmd)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        cmd.LastChangeUser = CurrentUser;
        return Json(await financialService.SaveFinancialAsync(cmd));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteFinancial(DeleteFinancialInformationCommand cmd)
    {
        cmd.LastChangeUser = CurrentUser;
        await financialService.DeleteFinancialAsync(cmd);
        return Json(new { success = true });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private string CurrentUser => User.Identity?.Name ?? "system";

    private static int GetCategoryOtherId(LookupData l) =>
        l.Categories.FirstOrDefault(c =>
            c.CategoryName.Equals("Other", StringComparison.OrdinalIgnoreCase))?.CategoryId ?? 0;

    private static int GetProjectTypeOtherId(LookupData l) =>
        l.ProjectTypes.FirstOrDefault(p =>
            p.ProjectTypeName.Equals("Other", StringComparison.OrdinalIgnoreCase))?.ProjectTypeId ?? 0;
}
